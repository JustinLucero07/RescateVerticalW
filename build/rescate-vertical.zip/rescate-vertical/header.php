<?php
/**
 * Header template.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#rv-content"><?php esc_html_e( 'Saltar al contenido', 'rescate-vertical' ); ?></a>

<header class="rv-header">
	<div class="rv-header-inner">
		<?php if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) : ?>
			<div class="rv-brand rv-brand--logo">
				<?php the_custom_logo(); ?>
				<a class="rv-brand-text" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<span class="rv-brand-name"><?php bloginfo( 'name' ); ?></span>
				</a>
			</div>
		<?php else : ?>
			<a class="rv-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true" focusable="false">
					<path d="M12 1.8v5.2" stroke="#101820" stroke-width="2" stroke-linecap="round"/>
					<circle cx="12" cy="10" r="3" stroke="#D9502B" stroke-width="2"/>
					<circle cx="12" cy="15.6" r="3" stroke="#D9502B" stroke-width="2"/>
					<path d="M12 18.6v3.6" stroke="#101820" stroke-width="2" stroke-linecap="round"/>
				</svg>
				<span class="rv-brand-name"><?php bloginfo( 'name' ); ?></span>
			</a>
		<?php endif; ?>

		<button type="button" class="rv-nav-toggle" id="rv-nav-toggle" aria-expanded="false" aria-controls="rv-nav">
			<span class="rv-nav-toggle-bars" aria-hidden="true"><span></span><span></span><span></span></span>
			<?php esc_html_e( 'Menú', 'rescate-vertical' ); ?>
		</button>

		<nav class="rv-nav" id="rv-nav" aria-label="<?php esc_attr_e( 'Navegación principal', 'rescate-vertical' ); ?>">
			<?php
			if ( has_nav_menu( 'primary' ) ) {
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => '',
						'depth'          => 1,
					)
				);
			} else {
				rv_fallback_menu();
			}
			?>
			<a class="rv-nav-cta" href="<?php echo esc_url( rv_section_url( 'fisica' ) ); ?>">
				<?php esc_html_e( 'Simulador', 'rescate-vertical' ); ?>
			</a>
		</nav>
	</div>
</header>

<main id="rv-content">
